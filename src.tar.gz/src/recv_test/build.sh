g++ -o send send.cpp -pthread -fpermissive
