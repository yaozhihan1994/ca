

class T{
public:
static void test();
};
