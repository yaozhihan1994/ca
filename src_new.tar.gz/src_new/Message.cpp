﻿
/***********************************************
* @addtogroup Nebula
* @{
* @file  : Message.cpp
* @brief :
* @date  : 2019-05-13
***********************************************/

//--------------------------------------------------
// Copyright (c) Beijing Nebula Link Technology Co.,Ltd
//--------------------------------------------------

#include "Message.h"

using namespace MESSAGE;







/**
* @}
**/

